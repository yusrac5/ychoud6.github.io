[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/PJPP14qu)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=12804231&assignment_repo_type=AssignmentRepo)
# SE2202_Fall2023_tutorial5

The purpose of this tutorial is to create a colour guessing name.
You will set an RGB color and have 6 colours to pick from, you need to i
dentify the RGB colour by clicking on the correct circle. 

You are given the HTML and CSS code and the skeleton of the JS. Fill in the script file as needed. 
You should make sure that your HTML page is published on GitHub Pages and that the game can be played.

Here are some screenshot examples of the expected game: 

Beginning: 

![Beginning image](beginning.png)

Mid Play:

![Beginning image](mid.png)

End:

![Beginning image](end.png)

Pressing the restart button should restart the game at any time and pressing play again should do the same. 
